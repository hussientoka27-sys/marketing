function register() {
    let user = document.getElementById("username").value;
    let pass = document.getElementById("password").value;

    if (user === "" || pass === "") {
        document.getElementById("msg").innerText = "Please enter data";
        return;
    }

    localStorage.setItem(user, pass);
    document.getElementById("msg").innerText = "Registered Successfully ✅";
}

function login() {
    let user = document.getElementById("username").value;
    let pass = document.getElementById("password").value;

    let storedPass = localStorage.getItem(user);

    if (storedPass === pass) {
        localStorage.setItem("loggedUser", user);
        window.location.href = "dashboard.html";
    } else {
        document.getElementById("msg").innerText = "Wrong Username or Password ❌";
    }
}
