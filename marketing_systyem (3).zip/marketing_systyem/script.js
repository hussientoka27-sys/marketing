let lang = "en";
let chart;

// 🌐 تغيير اللغة
function toggleLang() {

    if (lang === "en") {
        lang = "ar";

        document.getElementById("title").innerText = "تحليل التسويق";
        document.getElementById("lblBusiness").innerText = "نوع النشاط";
        document.getElementById("lblAge").innerText = "الفئة العمرية";
        document.getElementById("lblBudget").innerText = "الميزانية";
        document.getElementById("lblGoal").innerText = "الهدف";
        document.getElementById("analyzeBtn").innerText = "تحليل";
        document.getElementById("logoutBtn").innerText = "تسجيل الخروج";

    } else {
        lang = "en";

        document.getElementById("title").innerText = "Marketing Analysis";
        document.getElementById("lblBusiness").innerText = "Business Type";
        document.getElementById("lblAge").innerText = "Target Age";
        document.getElementById("lblBudget").innerText = "Budget";
        document.getElementById("lblGoal").innerText = "Goal";
        document.getElementById("analyzeBtn").innerText = "Analyze";
        document.getElementById("logoutBtn").innerText = "Logout";
    }
}

// 🧠 الذكاء التحليلي
function analyze() {

    let business = document.getElementById("business").value;
    let age = document.getElementById("age").value;
    let budget = parseInt(document.getElementById("budget").value) || 0;
    let goal = document.getElementById("goal").value;

    let score = {
        Facebook: 0,
        Instagram: 0,
        TikTok: 0
    };

    // 👶 العمر
    if (age === "young") {
        score.Instagram += 3;
        score.TikTok += 4;
    } else {
        score.Facebook += 3;
    }

    // 🏪 نوع البيزنس
    if (business === "clothes") {
        score.Instagram += 4;
        score.TikTok += 2;
    }

    if (business === "food") {
        score.Instagram += 3;
        score.Facebook += 2;
    }

    if (business === "services") {
        score.Facebook += 3;
    }

    // 💰 الميزانية
    if (budget < 1000) {
        score.Facebook += 4;
    } else if (budget < 3000) {
        score.Instagram += 3;
    } else {
        score.TikTok += 3;
        score.Instagram += 2;
    }

    // 🎯 الهدف
    if (goal === "awareness") {
        score.TikTok += 4;
    } else {
        score.Facebook += 2;
        score.Instagram += 3;
    }

    

    // 🏆 اختيار الأفضل
    let best = Object.keys(score).reduce((a, b) => score[a] > score[b] ? a : b);

    // 📝 نص النتيجة
    let resultText = "";

    if (lang === "ar") {
        resultText = `
            <h3>أفضل منصة: ${best}</h3>
            <p>فيسبوك: ${score.Facebook}</p>
            <p>إنستجرام: ${score.Instagram}</p>
            <p>تيك توك: ${score.TikTok}</p>
        `;
    } else {
        resultText = `
            let history = JSON.parse(localStorage.getItem("history")) || [];

history.push({
    platform: best,
    facebook: score.Facebook,
    instagram: score.Instagram,
    tiktok: score.TikTok,
    time: new Date().toLocaleString()
});

localStorage.setItem("history", JSON.stringify(history));<h3>Best Platform: ${best}</h3>
            <p>Facebook: ${score.Facebook}</p>
            <p>Instagram: ${score.Instagram}</p>
            <p>TikTok: ${score.TikTok}</p>
        `;
    }

    document.getElementById("result").innerHTML = resultText;

    // 📊 الرسم البياني
    let ctx = document.getElementById("myChart").getContext("2d");

    if (chart) chart.destroy();

    chart = new Chart(ctx, {
        type: "bar",
        data: {
            labels: ["Facebook", "Instagram", "TikTok"],
            datasets: [{
                label: lang === "ar" ? "النتيجة" : "Score",
                data: [score.Facebook, score.Instagram, score.TikTok],
                backgroundColor: ["blue", "pink", "red"]
            }]
        }
    });
}

// 🚪 تسجيل خروج
function logout() {
    window.location.href = "index.html";
}

function logout() {
    window.location.href = "index.html";
}

/* 👇 هنا تحط الكود ده */
function showHistory() {
    let history = JSON.parse(localStorage.getItem("history")) || [];

    let html = "";

    history.slice(-5).reverse().forEach(item => {
        html += `
        <div style="background:#0f2027; padding:10px; margin:5px; border-radius:8px;">
            <p>Platform: ${item.platform}</p>
            <p>FB: ${item.facebook} | IG: ${item.instagram} | TT: ${item.tiktok}</p>
            <small>${item.time}</small>
        </div>
        `;
    });

    document.getElementById("history").innerHTML = html;
}
